/**
 *        @file: cmos.cpp
 *      @author: Parker Corbitt
 *        @date: March 03, 2024
 *       @brief: Add Description
 */

#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

///function prototypes

int main(int argc, char const *argv[]) {

   /*add code*/
   return 0;
}// main

//function definitions


//Things to tokenize for the cmos
//Basic Operators : = + - * / % += -= *= /= %= ++ --
      //= is 100
      //+ is 101
      //- is 102
      //* is 103
      /// is 104
      //% is 105
      //+= is 106
      //-= is 107
      //*= is 108
      ///= is 109
      //%= is 110
      //++ is 111
      //-- is 112

//Logical Operators : && || !
      //&& is 200
      //|| is 201

//Relational Operators : == != < > <= >=
      //== is 300
      //!= is 301
      //< is 302
      //> is 303
      //<= is 304
      //>= is 305

//Function Calls: printf, scanf, main, <other identifiers>
      //printf is 400
      //scanf is 401
      //main is 402
      //<other identifiers> is 403

//Function Definitions: int, float, char, void
      //int is 450
      //float is 451
      //double is 452
      //char is 453
      //void is 454

      //Looks like - <type> <identifier> ( <parameters> ) { <statements> }

//Keywords: if, else, while, for, do, break, return
      //if is 500
      //else is 501
      //while is 502
      //for is 503
      //do is 504
      //break is 505
      //return is 506
