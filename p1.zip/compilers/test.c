#include <math.h>
/**
 * ]
 */
#include <acc_prof.h>

int main(argc)
{
    printf("Bang");
    int x = 7;
    if (1 == 2)
    {
        printf("Blammo");
    }
}