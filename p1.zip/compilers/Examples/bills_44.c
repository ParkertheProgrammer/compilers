Script started on Mon Nov 15 12:21:03 2010
sp-011% ^[[A^[[A        a.out
Enter Cash Amount Needed > 80
Amount your Withdrawing = $ 80
***Remover Your Cash***
1 Fifties, 1 Twenties, 1 Tens Would you like another transaction Y or N?y
Enter Cash Amount Needed > 55
This Machine only dispenses multiples of Ten

Please Enter another Value60
Amount your Withdrawing = $ 60
***Remover Your Cash***
1 Fifties, 0 Twenties, 1 Tens Would you like another transaction Y or N?n
sp-011% exit
sp-011% 
script done on Mon Nov 15 12:21:36 2010
